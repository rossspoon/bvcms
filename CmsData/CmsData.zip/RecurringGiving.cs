using System; 
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Data;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Linq.Expressions;
using System.ComponentModel;

namespace CmsData
{
	[Table(Name="dbo.RecurringGiving")]
	public partial class RecurringGiving : INotifyPropertyChanging, INotifyPropertyChanged
	{
		private static PropertyChangingEventArgs emptyChangingEventArgs = new PropertyChangingEventArgs(String.Empty);
		
	#region Private Fields
		
		private int _PeopleId;
		
		private int? _AuNetCustId;
		
		private int? _AuNetCustPayId;
		
		private Guid? _SageCardGuid;
		
		private Guid? _SageBankGuid;
		
		private string _MaskedAccount;
		
		private string _MaskedCard;
		
		private string _Expires;
		
		private string _Ccv;
		
		private DateTime? _StartWhen;
		
		private string _Frequency;
		
		private string _Type;
		
		private DateTime? _LastModified;
		
		private int? _ModifiedBy;
		
		private DateTime? _LastDate;
		
   		
    	
		private EntityRef< Person> _Person;
		
	#endregion
	
    #region Extensibility Method Definitions
    partial void OnLoaded();
    partial void OnValidate(System.Data.Linq.ChangeAction action);
    partial void OnCreated();
		
		partial void OnPeopleIdChanging(int value);
		partial void OnPeopleIdChanged();
		
		partial void OnAuNetCustIdChanging(int? value);
		partial void OnAuNetCustIdChanged();
		
		partial void OnAuNetCustPayIdChanging(int? value);
		partial void OnAuNetCustPayIdChanged();
		
		partial void OnSageCardGuidChanging(Guid? value);
		partial void OnSageCardGuidChanged();
		
		partial void OnSageBankGuidChanging(Guid? value);
		partial void OnSageBankGuidChanged();
		
		partial void OnMaskedAccountChanging(string value);
		partial void OnMaskedAccountChanged();
		
		partial void OnMaskedCardChanging(string value);
		partial void OnMaskedCardChanged();
		
		partial void OnExpiresChanging(string value);
		partial void OnExpiresChanged();
		
		partial void OnCcvChanging(string value);
		partial void OnCcvChanged();
		
		partial void OnStartWhenChanging(DateTime? value);
		partial void OnStartWhenChanged();
		
		partial void OnFrequencyChanging(string value);
		partial void OnFrequencyChanged();
		
		partial void OnTypeChanging(string value);
		partial void OnTypeChanged();
		
		partial void OnLastModifiedChanging(DateTime? value);
		partial void OnLastModifiedChanged();
		
		partial void OnModifiedByChanging(int? value);
		partial void OnModifiedByChanged();
		
		partial void OnLastDateChanging(DateTime? value);
		partial void OnLastDateChanged();
		
    #endregion
		public RecurringGiving()
		{
			
			
			this._Person = default(EntityRef< Person>); 
			
			OnCreated();
		}

		
    #region Columns
		
		[Column(Name="PeopleId", UpdateCheck=UpdateCheck.Never, Storage="_PeopleId", DbType="int NOT NULL", IsPrimaryKey=true)]
		public int PeopleId
		{
			get { return this._PeopleId; }

			set
			{
				if (this._PeopleId != value)
				{
				
					if (this._Person.HasLoadedOrAssignedValue)
						throw new System.Data.Linq.ForeignKeyReferenceAlreadyHasValueException();
				
                    this.OnPeopleIdChanging(value);
					this.SendPropertyChanging();
					this._PeopleId = value;
					this.SendPropertyChanged("PeopleId");
					this.OnPeopleIdChanged();
				}

			}

		}

		
		[Column(Name="AuNetCustId", UpdateCheck=UpdateCheck.Never, Storage="_AuNetCustId", DbType="int")]
		public int? AuNetCustId
		{
			get { return this._AuNetCustId; }

			set
			{
				if (this._AuNetCustId != value)
				{
				
                    this.OnAuNetCustIdChanging(value);
					this.SendPropertyChanging();
					this._AuNetCustId = value;
					this.SendPropertyChanged("AuNetCustId");
					this.OnAuNetCustIdChanged();
				}

			}

		}

		
		[Column(Name="AuNetCustPayId", UpdateCheck=UpdateCheck.Never, Storage="_AuNetCustPayId", DbType="int")]
		public int? AuNetCustPayId
		{
			get { return this._AuNetCustPayId; }

			set
			{
				if (this._AuNetCustPayId != value)
				{
				
                    this.OnAuNetCustPayIdChanging(value);
					this.SendPropertyChanging();
					this._AuNetCustPayId = value;
					this.SendPropertyChanged("AuNetCustPayId");
					this.OnAuNetCustPayIdChanged();
				}

			}

		}

		
		[Column(Name="SageCardGuid", UpdateCheck=UpdateCheck.Never, Storage="_SageCardGuid", DbType="uniqueidentifier")]
		public Guid? SageCardGuid
		{
			get { return this._SageCardGuid; }

			set
			{
				if (this._SageCardGuid != value)
				{
				
                    this.OnSageCardGuidChanging(value);
					this.SendPropertyChanging();
					this._SageCardGuid = value;
					this.SendPropertyChanged("SageCardGuid");
					this.OnSageCardGuidChanged();
				}

			}

		}

		
		[Column(Name="SageBankGuid", UpdateCheck=UpdateCheck.Never, Storage="_SageBankGuid", DbType="uniqueidentifier")]
		public Guid? SageBankGuid
		{
			get { return this._SageBankGuid; }

			set
			{
				if (this._SageBankGuid != value)
				{
				
                    this.OnSageBankGuidChanging(value);
					this.SendPropertyChanging();
					this._SageBankGuid = value;
					this.SendPropertyChanged("SageBankGuid");
					this.OnSageBankGuidChanged();
				}

			}

		}

		
		[Column(Name="MaskedAccount", UpdateCheck=UpdateCheck.Never, Storage="_MaskedAccount", DbType="varchar(30)")]
		public string MaskedAccount
		{
			get { return this._MaskedAccount; }

			set
			{
				if (this._MaskedAccount != value)
				{
				
                    this.OnMaskedAccountChanging(value);
					this.SendPropertyChanging();
					this._MaskedAccount = value;
					this.SendPropertyChanged("MaskedAccount");
					this.OnMaskedAccountChanged();
				}

			}

		}

		
		[Column(Name="MaskedCard", UpdateCheck=UpdateCheck.Never, Storage="_MaskedCard", DbType="varchar(30)")]
		public string MaskedCard
		{
			get { return this._MaskedCard; }

			set
			{
				if (this._MaskedCard != value)
				{
				
                    this.OnMaskedCardChanging(value);
					this.SendPropertyChanging();
					this._MaskedCard = value;
					this.SendPropertyChanged("MaskedCard");
					this.OnMaskedCardChanged();
				}

			}

		}

		
		[Column(Name="Expires", UpdateCheck=UpdateCheck.Never, Storage="_Expires", DbType="varchar(10)")]
		public string Expires
		{
			get { return this._Expires; }

			set
			{
				if (this._Expires != value)
				{
				
                    this.OnExpiresChanging(value);
					this.SendPropertyChanging();
					this._Expires = value;
					this.SendPropertyChanged("Expires");
					this.OnExpiresChanged();
				}

			}

		}

		
		[Column(Name="ccv", UpdateCheck=UpdateCheck.Never, Storage="_Ccv", DbType="varchar(5)")]
		public string Ccv
		{
			get { return this._Ccv; }

			set
			{
				if (this._Ccv != value)
				{
				
                    this.OnCcvChanging(value);
					this.SendPropertyChanging();
					this._Ccv = value;
					this.SendPropertyChanged("Ccv");
					this.OnCcvChanged();
				}

			}

		}

		
		[Column(Name="StartWhen", UpdateCheck=UpdateCheck.Never, Storage="_StartWhen", DbType="datetime")]
		public DateTime? StartWhen
		{
			get { return this._StartWhen; }

			set
			{
				if (this._StartWhen != value)
				{
				
                    this.OnStartWhenChanging(value);
					this.SendPropertyChanging();
					this._StartWhen = value;
					this.SendPropertyChanged("StartWhen");
					this.OnStartWhenChanged();
				}

			}

		}

		
		[Column(Name="Frequency", UpdateCheck=UpdateCheck.Never, Storage="_Frequency", DbType="varchar(2)")]
		public string Frequency
		{
			get { return this._Frequency; }

			set
			{
				if (this._Frequency != value)
				{
				
                    this.OnFrequencyChanging(value);
					this.SendPropertyChanging();
					this._Frequency = value;
					this.SendPropertyChanged("Frequency");
					this.OnFrequencyChanged();
				}

			}

		}

		
		[Column(Name="Type", UpdateCheck=UpdateCheck.Never, Storage="_Type", DbType="varchar(2)")]
		public string Type
		{
			get { return this._Type; }

			set
			{
				if (this._Type != value)
				{
				
                    this.OnTypeChanging(value);
					this.SendPropertyChanging();
					this._Type = value;
					this.SendPropertyChanged("Type");
					this.OnTypeChanged();
				}

			}

		}

		
		[Column(Name="LastModified", UpdateCheck=UpdateCheck.Never, Storage="_LastModified", DbType="datetime")]
		public DateTime? LastModified
		{
			get { return this._LastModified; }

			set
			{
				if (this._LastModified != value)
				{
				
                    this.OnLastModifiedChanging(value);
					this.SendPropertyChanging();
					this._LastModified = value;
					this.SendPropertyChanged("LastModified");
					this.OnLastModifiedChanged();
				}

			}

		}

		
		[Column(Name="ModifiedBy", UpdateCheck=UpdateCheck.Never, Storage="_ModifiedBy", DbType="int")]
		public int? ModifiedBy
		{
			get { return this._ModifiedBy; }

			set
			{
				if (this._ModifiedBy != value)
				{
				
                    this.OnModifiedByChanging(value);
					this.SendPropertyChanging();
					this._ModifiedBy = value;
					this.SendPropertyChanged("ModifiedBy");
					this.OnModifiedByChanged();
				}

			}

		}

		
		[Column(Name="LastDate", UpdateCheck=UpdateCheck.Never, Storage="_LastDate", DbType="datetime")]
		public DateTime? LastDate
		{
			get { return this._LastDate; }

			set
			{
				if (this._LastDate != value)
				{
				
                    this.OnLastDateChanging(value);
					this.SendPropertyChanging();
					this._LastDate = value;
					this.SendPropertyChanged("LastDate");
					this.OnLastDateChanged();
				}

			}

		}

		
    #endregion
        
    #region Foreign Key Tables
   		
	#endregion
	
	#region Foreign Keys
    	
		[Association(Name="FK_AuthorizeNetIds_People", Storage="_Person", ThisKey="PeopleId", IsForeignKey=true)]
		public Person Person
		{
			get { return this._Person.Entity; }

			set
			{
				Person previousValue = this._Person.Entity;
				if (((previousValue != value) 
							|| (this._Person.HasLoadedOrAssignedValue == false)))
				{
					this.SendPropertyChanging();
					if (previousValue != null)
					{
						this._Person.Entity = null;
						previousValue.RecurringGivings.Remove(this);
					}

					this._Person.Entity = value;
					if (value != null)
					{
						value.RecurringGivings.Add(this);
						
						this._PeopleId = value.PeopleId;
						
					}

					else
					{
						
						this._PeopleId = default(int);
						
					}

					this.SendPropertyChanged("Person");
				}

			}

		}

		
	#endregion
	
		public event PropertyChangingEventHandler PropertyChanging;
		protected virtual void SendPropertyChanging()
		{
			if ((this.PropertyChanging != null))
				this.PropertyChanging(this, emptyChangingEventArgs);
		}

		public event PropertyChangedEventHandler PropertyChanged;
		protected virtual void SendPropertyChanged(String propertyName)
		{
			if ((this.PropertyChanged != null))
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}

   		
	}

}

